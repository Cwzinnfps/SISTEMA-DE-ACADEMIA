"""
Menu principal do sistema: exibe as opções e direciona para os serviços.
"""

from src.services.associados_service import cadastrar_associado, listar_associados
from src.services.aulas_service import agendar_aula, listar_aulas, cancelar_aula
from src.services.pagamentos_service import registrar_pagamento, extrato
from src.utils.storage import carregar

OPCOES = {
    "1": ("Cadastrar associado", cadastrar_associado),
    "2": ("Listar associados", listar_associados),
    "3": ("Agendar aula", agendar_aula),
    "4": ("Listar aulas agendadas", listar_aulas),
    "5": ("Cancelar aula", cancelar_aula),
    "6": ("Registrar pagamento", registrar_pagamento),
    "7": ("Ver extrato de pagamentos", extrato),
}


def exibir_cabecalho():
    print("\n" + "=" * 45)
    print("   ACADEMIA UNIT-PE — SISTEMA DE GESTÃO")
    print("=" * 45)
    for chave, (descricao, _) in OPCOES.items():
        print(f"  {chave}. {descricao}")
    print("  0. Sair")


def iniciar():
    dados = carregar()

    while True:
        exibir_cabecalho()
        opcao = input("\nOpção: ").strip()

        if opcao == "0":
            print("\nAté logo!\n")
            break

        if opcao in OPCOES:
            _, funcao = OPCOES[opcao]
            funcao(dados)
        else:
            print("Opção inválida.")
