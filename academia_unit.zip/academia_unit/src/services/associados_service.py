"""
Serviço de gestão de associados: cadastro e listagem.
"""

from datetime import date, timedelta

from src.constants import PLANOS
from src.utils.display import titulo, linha, pausar
from src.utils.storage import salvar


def cadastrar_associado(dados):
    titulo("CADASTRAR ASSOCIADO")
    nome = input("Nome: ").strip()
    cpf = input("CPF: ").strip()

    print("\nPlanos disponíveis:")
    for k, p in PLANOS.items():
        print(f"  {k}. {p['nome']} — R$ {p['valor']:.2f} ({p['meses']} mês/es)")
    escolha = input("Escolha o plano (1-4): ").strip()

    if escolha not in PLANOS:
        print("Plano inválido.")
        pausar()
        return

    plano = PLANOS[escolha]
    vencimento = (date.today() + timedelta(days=30 * plano["meses"])).isoformat()
    associado_id = str(dados["proximo_id"])
    dados["proximo_id"] += 1

    dados["associados"][associado_id] = {
        "nome": nome,
        "cpf": cpf,
        "plano": plano["nome"],
        "vencimento": vencimento,
    }
    dados["pagamentos"].append({
        "id": associado_id,
        "data": date.today().isoformat(),
        "desc": f"Adesão {plano['nome']}",
        "valor": plano["valor"],
    })

    salvar(dados)
    print(f"\nCadastrado! ID: {associado_id} | Plano: {plano['nome']} | Vence: {vencimento}")
    pausar()


def listar_associados(dados):
    titulo("ASSOCIADOS CADASTRADOS")
    if not dados["associados"]:
        print("Nenhum associado.")
    else:
        linha()
        for associado_id, associado in dados["associados"].items():
            print(f"[{associado_id}] {associado['nome']} | {associado['plano']} | Vence: {associado['vencimento']}")
        linha()
    pausar()
