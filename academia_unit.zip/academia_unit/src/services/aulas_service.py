"""
Serviço de gestão de aulas coletivas: agendamento, listagem e cancelamento.
"""

from src.constants import MODALIDADES
from src.utils.display import titulo, linha, pausar
from src.utils.storage import salvar


def agendar_aula(dados):
    titulo("AGENDAR AULA")
    associado_id = input("ID do associado: ").strip()
    if associado_id not in dados["associados"]:
        print("Associado não encontrado.")
        pausar()
        return

    print("\nModalidades:")
    for i, modalidade in enumerate(MODALIDADES, 1):
        print(f"  {i}. {modalidade}")
    escolha = input("Escolha a modalidade (1-5): ").strip()

    if not escolha.isdigit() or not (1 <= int(escolha) <= len(MODALIDADES)):
        print("Opção inválida.")
        pausar()
        return

    modalidade = MODALIDADES[int(escolha) - 1]
    data_aula = input("Data da aula (AAAA-MM-DD): ").strip()
    hora = input("Hora (ex: 08:00): ").strip()

    dados["aulas"].append({
        "id_associado": associado_id,
        "nome": dados["associados"][associado_id]["nome"],
        "modalidade": modalidade,
        "data": data_aula,
        "hora": hora,
        "status": "confirmado",
    })

    salvar(dados)
    print(f"\nAula de {modalidade} agendada para {data_aula} às {hora}!")
    pausar()


def listar_aulas(dados):
    titulo("AULAS AGENDADAS")
    ativas = [a for a in dados["aulas"] if a["status"] == "confirmado"]
    if not ativas:
        print("Nenhuma aula agendada.")
    else:
        linha()
        for aula in ativas:
            print(f"{aula['data']} {aula['hora']} | {aula['modalidade']} | {aula['nome']} (ID {aula['id_associado']})")
        linha()
    pausar()


def cancelar_aula(dados):
    titulo("CANCELAR AULA")
    associado_id = input("ID do associado: ").strip()

    indices_ativos = [
        i for i, a in enumerate(dados["aulas"])
        if a["id_associado"] == associado_id and a["status"] == "confirmado"
    ]

    if not indices_ativos:
        print("Nenhuma aula ativa para esse associado.")
        pausar()
        return

    for posicao, i in enumerate(indices_ativos):
        aula = dados["aulas"][i]
        print(f"  {posicao}. {aula['modalidade']} — {aula['data']} {aula['hora']}")

    escolha = input("Número para cancelar: ").strip()
    if not escolha.isdigit() or int(escolha) >= len(indices_ativos):
        print("Opção inválida.")
        pausar()
        return

    dados["aulas"][indices_ativos[int(escolha)]]["status"] = "cancelado"
    salvar(dados)
    print("Aula cancelada.")
    pausar()
