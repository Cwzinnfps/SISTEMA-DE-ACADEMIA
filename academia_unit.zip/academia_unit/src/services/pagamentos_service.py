"""
Serviço de gestão financeira: registro de pagamentos e extrato.
"""

from datetime import date

from src.utils.display import titulo, linha, pausar
from src.utils.storage import salvar


def registrar_pagamento(dados):
    titulo("REGISTRAR PAGAMENTO")
    associado_id = input("ID do associado: ").strip()

    if associado_id not in dados["associados"]:
        print("Associado não encontrado.")
        pausar()
        return

    associado = dados["associados"][associado_id]
    print(f"Associado: {associado['nome']} | Plano: {associado['plano']}")

    descricao = input("Descrição (ex: Mensalidade): ").strip() or "Mensalidade"
    valor_str = input("Valor (R$): ").strip()

    try:
        valor = float(valor_str)
    except ValueError:
        print("Valor inválido.")
        pausar()
        return

    dados["pagamentos"].append({
        "id": associado_id,
        "data": date.today().isoformat(),
        "desc": descricao,
        "valor": valor,
    })

    salvar(dados)
    print(f"Pagamento de R$ {valor:.2f} registrado!")
    pausar()


def extrato(dados):
    titulo("EXTRATO DE PAGAMENTOS")
    associado_id = input("ID do associado (ou ENTER para todos): ").strip()

    pagamentos = dados["pagamentos"]
    if associado_id:
        pagamentos = [p for p in pagamentos if p["id"] == associado_id]

    if not pagamentos:
        print("Nenhum pagamento encontrado.")
        pausar()
        return

    linha()
    total = 0
    for pagamento in pagamentos:
        print(f"{pagamento['data']} | ID {pagamento['id']} | {pagamento['desc']} | R$ {pagamento['valor']:.2f}")
        total += pagamento["valor"]
    linha()
    print(f"Total: R$ {total:.2f}")
    pausar()
