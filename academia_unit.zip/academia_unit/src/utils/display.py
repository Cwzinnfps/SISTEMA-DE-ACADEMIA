"""
Funções utilitárias de exibição no terminal.
"""


def titulo(texto):
    print(f"\n=== {texto} ===")


def linha():
    print("-" * 45)


def pausar():
    input("\n[ENTER para continuar]")
