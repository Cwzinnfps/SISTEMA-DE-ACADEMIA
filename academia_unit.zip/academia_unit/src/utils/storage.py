"""
Camada de persistência: carrega e salva os dados do sistema em um
arquivo JSON local (data/dados.json).
"""

import json
import os

_RAIZ_PROJETO = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ARQUIVO = os.path.join(_RAIZ_PROJETO, "data", "dados.json")

ESTRUTURA_INICIAL = {
    "associados": {},
    "aulas": [],
    "pagamentos": [],
    "proximo_id": 1,
}


def carregar():
    """Carrega os dados do arquivo JSON. Cria a estrutura padrão se não existir."""
    if os.path.exists(ARQUIVO):
        with open(ARQUIVO, "r", encoding="utf-8") as f:
            return json.load(f)
    return dict(ESTRUTURA_INICIAL)


def salvar(dados):
    """Grava os dados no arquivo JSON, criando a pasta caso necessário."""
    os.makedirs(os.path.dirname(ARQUIVO), exist_ok=True)
    with open(ARQUIVO, "w", encoding="utf-8") as f:
        json.dump(dados, f, ensure_ascii=False, indent=2)
