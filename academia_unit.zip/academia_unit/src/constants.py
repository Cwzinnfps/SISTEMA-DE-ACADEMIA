"""
Constantes do sistema: planos de associação e modalidades de aula.
"""

PLANOS = {
    "1": {"nome": "Mensal",    "valor": 120.0,  "meses": 1},
    "2": {"nome": "Semestral", "valor": 600.0,  "meses": 6},
    "3": {"nome": "Anual",     "valor": 1000.0, "meses": 12},
    "4": {"nome": "Estudante", "valor": 350.0,  "meses": 6},
}

MODALIDADES = [
    "Musculação Livre",
    "Funcional",
    "Yoga",
    "Spinning",
    "Natação",
]
