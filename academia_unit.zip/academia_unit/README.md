# 🏋️ Sistema de Gestão de Academia Universitária

Sistema em Python para gestão de associados, planos, aulas coletivas e pagamentos de uma academia universitária.

> Projeto Semestral — Engenharia de Software | UNIT-PE | 2026.1
> Prof. Dr. David Barrientos

---

## 📁 Estrutura do projeto

```
academia_unit/
├── main.py                        # Ponto de entrada do sistema
├── data/
│   └── dados.json                 # Gerado automaticamente na 1ª execução
├── src/
│   ├── constants.py                # Planos e modalidades de aula
│   ├── menu.py                     # Menu principal (interface)
│   ├── services/
│   │   ├── associados_service.py   # Cadastro e listagem de associados
│   │   ├── aulas_service.py        # Agendamento/cancelamento de aulas
│   │   └── pagamentos_service.py   # Registro e extrato de pagamentos
│   └── utils/
│       ├── storage.py              # Persistência em JSON
│       └── display.py              # Funções auxiliares de exibição
└── README.md
```

---

## ⚙️ Como executar

Requisitos: **Python 3.6+** (sem dependências externas)

```bash
git clone https://github.com/seu-usuario/academia-unit.git
cd academia-unit
python main.py
```

---

## 🗂️ Funcionalidades

| Opção | Função |
|-------|--------|
| 1 | Cadastrar associado |
| 2 | Listar associados |
| 3 | Agendar aula coletiva |
| 4 | Listar aulas agendadas |
| 5 | Cancelar agendamento |
| 6 | Registrar pagamento |
| 7 | Ver extrato financeiro |
| 0 | Sair |

---

## 💳 Planos disponíveis

| Plano | Valor | Duração |
|-------|-------|---------|
| Mensal | R$ 120,00 | 1 mês |
| Semestral | R$ 600,00 | 6 meses |
| Anual | R$ 1.000,00 | 12 meses |
| Estudante | R$ 350,00 | 6 meses |

---

## 🏃 Modalidades de aula

- Musculação Livre
- Funcional
- Yoga
- Spinning
- Natação

---

## 🗄️ Persistência de dados

Os dados são salvos automaticamente em `data/dados.json`, estruturado em três coleções:

- **associados** — id, nome, cpf, plano, vencimento
- **aulas** — agendamentos com modalidade, data, hora e status
- **pagamentos** — histórico financeiro por associado

---

## 📄 Licença

Projeto acadêmico — UNIT-PE 2026.1
